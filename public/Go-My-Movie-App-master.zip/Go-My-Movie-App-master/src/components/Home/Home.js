import React from "react";

const Home = () => {
  return <div style={{ marginTop: "100px" }}>Home</div>;
};

export default Home;
