import React from 'react'
import './home.css';


const Home = () => {
  return (
      <div className='no'>
              <h1  style={{ marginTop: "300px" , textAlign:"center" , color:"white"}}>
         
         
              Films, séries TV et bien plus en illimité <br/> 
             Où que vous soyez. Annulez à tout moment.
             
              </h1>
      </div>
  )
}

export default Home